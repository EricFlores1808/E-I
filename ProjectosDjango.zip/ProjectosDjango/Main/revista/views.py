from django.shortcuts import render, get_object_or_404, redirect
from .models import Producto
from .forms import ProductoForm

def index(request):
    productos = Producto.objects.all()
    return render(request, 'revista/index.html', {'productos': productos})

def novias(request):
    productos = Producto.objects.filter(categoria='novias')
    return render(request, 'revista/novias.html', {'productos': productos})

def novios(request):
    productos = Producto.objects.filter(categoria='novios')
    return render(request, 'revista/novios.html', {'productos': productos})

def iniciar(request):
    return render(request, 'revista/iniciar.html')

def registro(request):
    return render(request, 'revista/registro.html')

def producto_nuevo(request):
    if request.method == "POST":
        form = ProductoForm(request.POST, request.FILES)
        if form.is_valid():
            producto = form.save()
            return redirect('index')
    else:
        form = ProductoForm()
    return render(request, 'revista/producto_editar.html', {'form': form})

def producto_editar(request, pk):
    producto = get_object_or_404(Producto, pk=pk)
    if request.method == "POST":
        form = ProductoForm(request.POST, request.FILES, instance=producto)
        if form.is_valid():
            producto = form.save()
            return redirect('index')
    else:
        form = ProductoForm(instance=producto)
    return render(request, 'revista/producto_editar.html', {'form': form})

def producto_borrar(request, pk):
    producto = get_object_or_404(Producto, pk=pk)
    producto.delete()
    return redirect('index')
