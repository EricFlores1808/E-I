from django.contrib import admin
from .models import Producto

@admin.register(Producto)
class ProductoAdmin(admin.ModelAdmin):
    list_display = ('nombre', 'precio', 'descripcion', 'imagen')

    def get_queryset(self, request):
        qs = super().get_queryset(request)
        return qs.order_by('precio')

