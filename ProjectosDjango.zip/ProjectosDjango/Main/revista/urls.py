from django.urls import path
from . import views

urlpatterns = [
    path('', views.index, name='index'),
    path('novias/', views.novias, name='novias'),
    path('novios/', views.novios, name='novios'),
    path('iniciar/', views.iniciar, name='iniciar'),
    path('registro/', views.registro, name='registro'),
    path('producto/nuevo/', views.producto_nuevo, name='producto_nuevo'),
    path('producto/<int:pk>/editar/', views.producto_editar, name='producto_editar'),
    path('producto/<int:pk>/borrar/', views.producto_borrar, name='producto_borrar'),
]



