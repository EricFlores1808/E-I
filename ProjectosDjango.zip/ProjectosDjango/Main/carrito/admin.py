from django.contrib import admin
from .models import Carrito

@admin.register(Carrito)
class CarritoAdmin(admin.ModelAdmin):
    list_display = ('nombre', 'precio', 'imagen')

    def get_queryset(self, request):
        qs = super().get_queryset(request)
        return qs.order_by('precio')

