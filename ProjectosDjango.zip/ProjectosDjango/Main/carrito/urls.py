from django.urls import path
from . import views

urlpatterns = [
    path('', views.carrito_lista, name='carrito_lista'),
    path('detalle/<int:pk>/', views.carrito_detalle, name='carrito_detalle'),
    path('agregar/', views.carrito_agregar, name='carrito_agregar'),
    path('editar/<int:pk>/', views.carrito_actualizar, name='carrito_actualizar'),
    path('eliminar/<int:pk>/', views.carrito_eliminar, name='carrito_eliminar'),
]

