from django.shortcuts import render, redirect
from .forms import CarritoForm
from .models import Carrito

def agregar_producto_al_carrito(request):
    if request.method == 'POST':
        form = CarritoForm(request.POST, request.FILES)
        if form.is_valid():
            form.save()
            return redirect('carrito_lista')  
    else:
        form = CarritoForm()
    return render(request, 'carrito/carrito.html', {'form': form})