from django import forms
from crispy_forms.helper import FormHelper
from crispy_forms.layout import Submit
from .models import Carrito  

class CarritoForm(forms.ModelForm):
    class Meta:
        model = Carrito
        fields = ['nombre', 'precio', 'imagen']

    def _init_(self, *args, **kwargs):
        super()._init_(*args, **kwargs)
        self.helper = FormHelper()
        self.helper.form_method = 'POST'
        self.helper.add_input(Submit('submit', 'Guardar'))
