from django.db import models
from .models import Carrito

class Carrito(models.Model):
    nombre = models.CharField(max_length=100)
    precio = models.DecimalField(max_digits=10, decimal_places=2)
    imagen = models.ImageField(upload_to='carrito_productos/')

    def _str_(self):
        return self.nombre
